package co.com.rbm.bonos.gestionbonos.servicio;

import co.com.rbm.bonos.gestionbonos.model.ActivaCargaBono;
import co.com.rbm.bonos.gestionbonos.model.ActivaCargaBonoRta;
import co.com.rbm.bonos.gestionbonos.model.CrearBono;
import co.com.rbm.bonos.gestionbonos.model.CrearBonoRta;
import co.com.rbm.bonos.gestionbonos.model.RecuperarBono;
import co.com.rbm.bonos.gestionbonos.model.RecuperarBonoRta;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("/")
public interface GestionBonosServicio {
	@POST
	@Path("/crearBono")
	@Produces({ "application/json" })
	@Consumes({ "application/json" })
	CrearBonoRta crearBono(@Valid CrearBono paramCrearBono);

	@PUT
	@Path("/activarBono")
	@Produces({ "application/json" })
	@Consumes({ "application/json" })
	ActivaCargaBonoRta activarBono(@Valid ActivaCargaBono paramActivaCargaBono);

	@POST
	@Path("/recuperarBono")
	@Produces({ "application/json" })
	@Consumes({ "application/json" })
	RecuperarBonoRta recuperarBono(@Valid RecuperarBono paramRecuperarBono);
}
