package co.com.rbm.bonos.gestionbonos.spring;

import org.springframework.context.annotation.ImportResource;

@ImportResource({ "classpath:META-INF/springBoot/camelContext.xml" })
public class Application {
	public static void main(String[] args) {
	}
}
