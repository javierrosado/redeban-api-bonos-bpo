package co.com.rbm.bonos.gestionbonos.model;

public class ResponseError {
	private String codigoError;
	private String descripcionError;

	public String getCodigoError() {
		return this.codigoError;
	}

	public void setCodigoError(String codigoError) {
		this.codigoError = codigoError;
	}

	public String getDescripcionError() {
		return this.descripcionError;
	}

	public void setDescripcionError(String descripcionError) {
		this.descripcionError = descripcionError;
	}
}
