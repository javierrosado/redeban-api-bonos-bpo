package co.com.rbm.bonos.gestionbonos.exception;

import java.io.IOException;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;

public class ErrorExcepcionInterceptor extends AbstractPhaseInterceptor<Message> {
	private static final Log log = LogFactory.getLog(ErrorExcepcionInterceptor.class);

	public ErrorExcepcionInterceptor() {
		super("user-stream");
	}

	public void handleMessage(Message message) throws Fault {
		if (message.getExchange().getOutMessage().get("Content-Type") == null) {

			String descripcion, codigo,
					uri = (String) message.getExchange().getInMessage().get("org.apache.cxf.message.Message.PATH_INFO");
			String[] paths = uri.split("/");
			Integer responseCode = (Integer) message.getExchange().getOutMessage()
					.get("org.apache.cxf.message.Message.RESPONSE_CODE");

			HttpServletResponse response = (HttpServletResponse) message.getExchange().getInMessage()
					.get("HTTP.RESPONSE");
			response.setContentType("application/json");

			if (null == responseCode) {
				responseCode = Integer.valueOf(500);
				descripcion = "Error interno del servicio";
				codigo = "E09";
			} else {
				switch (responseCode.intValue()) {
				case 404:
					descripcion = "operacion no encontrada: " + paths[paths.length - 1];
					codigo = "E25";
					break;
				case 405:
					descripcion = "Metodo no permitido para la operacion: "
							+ message.getExchange().getInMessage().get("org.apache.cxf.request.method");
					codigo = "E26";
					break;
				default:
					responseCode = Integer.valueOf(500);
					descripcion = "Error interno del servicio";
					codigo = "E09";
					break;
				}
			}

			response.setStatus(responseCode.intValue());
			String salida = "{\"codigoError\": \"" + codigo + "\", \"descripcionError\": \"" + descripcion + "\"}";

			try {
				response.getOutputStream().write(salida.getBytes());
				response.getOutputStream().flush();
			} catch (IOException iOException) {
			}

			message.getInterceptorChain().abort();
		}
	}
}
