package co.com.rbm.bonos.gestionbonos.dao;

import co.com.rbm.bonos.gestionbonos.model.ActivaCargaBonoRta;
import co.com.rbm.bonos.gestionbonos.model.Bono;
import co.com.rbm.bonos.gestionbonos.model.CrearBonoRta;
import co.com.rbm.bonos.gestionbonos.model.RecuperarBonoRta;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.sql.DataSource;
import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AS400DAO {
	private static final Logger LOG = LoggerFactory.getLogger(AS400DAO.class);
	private DataSource dataSource = null;
	public static final Map<String, String> documentos = new HashMap<String, String>() {

	};

	public AS400DAO(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public void crearBono(Exchange exchange) throws SQLException {
		try (Connection conn = this.dataSource.getConnection();
				CallableStatement cstmt = conn.prepareCall("call " + exchange.getProperty("sp"))) {

			cstmt.setString(1, (String) exchange.getIn().getBody(String.class));
			cstmt.registerOutParameter(2, 12);
			cstmt.executeUpdate();
			String resultado = cstmt.getString(2);

			String numeroBono = StringUtils.substring(resultado, 181, 200);
			String codigo = StringUtils.substring(resultado, 46, 48);
			String mensaje = StringUtils.substring(resultado, 48, 123);

			CrearBonoRta rta = new CrearBonoRta();
			if (StringUtils.isNotBlank(numeroBono)) {
				rta.setNumeroBono(numeroBono.trim());
			}

			rta.setCodigoRespuesta(codigo);
			if (StringUtils.isNotBlank(mensaje)) {
				rta.setDescripcionRespuesta(mensaje.trim());
			}

			exchange.getIn().setBody(rta);
		}
	}

	public void activarBono(Exchange exchange) throws SQLException {
		try (Connection conn = this.dataSource.getConnection();
				CallableStatement cstmt = conn.prepareCall("call " + exchange.getProperty("sp"))) {

			cstmt.setString(1, (String) exchange.getIn().getBody(String.class));
			cstmt.registerOutParameter(2, 12);
			cstmt.executeUpdate();
			String resultado = cstmt.getString(2);

			String numeroAutorizacion = StringUtils.substring(resultado, 203, 209);
			String tipoDocumento = StringUtils.substring(resultado, 209, 211);
			String numeroDocumento = StringUtils.substring(resultado, 211, 227);
			String nombreCliente = StringUtils.substring(resultado, 227, 252);
			String numeroCuenta = StringUtils.substring(resultado, 252, 271);
			String estado = StringUtils.substring(resultado, 271, 272);
			String mensaje = StringUtils.substring(resultado, 48, 123);

			ActivaCargaBonoRta rta = new ActivaCargaBonoRta();
			if (StringUtils.isNotBlank(numeroAutorizacion)) {
				rta.setNumeroAutorizacion(numeroAutorizacion.trim());
			}
			if (StringUtils.isNotBlank(tipoDocumento)) {
				rta.setTipoDocumento((String) getKeyFromValue(documentos, tipoDocumento.trim()));
			}
			if (StringUtils.isNotBlank(numeroDocumento)) {
				rta.setNumeroDocumento(numeroDocumento.trim());
			}
			if (StringUtils.isNotBlank(nombreCliente)) {
				rta.setNombreCliente(nombreCliente.trim());
			}
			if (StringUtils.isNotBlank(numeroCuenta)) {
				rta.setNumeroCuenta(numeroCuenta.trim());
			}
			if (StringUtils.isNotBlank(estado)) {
				rta.setEstado(estado.trim());
			}

			rta.setCodigoRespuesta(StringUtils.substring(resultado, 46, 48));

			if (StringUtils.isNotBlank(mensaje)) {
				rta.setDescripcionRespuesta(mensaje.trim());
			}

			exchange.getIn().setBody(rta);
		}
	}

	public void recuperarBono(Exchange exchange) throws SQLException {
		try (Connection conn = this.dataSource.getConnection();
				CallableStatement cstmt = conn.prepareCall("call " + exchange.getProperty("sp"))) {

			cstmt.setString(1, (String) exchange.getIn().getBody(String.class));
			cstmt.registerOutParameter(2, 12);
			cstmt.executeUpdate();
			String resultado = cstmt.getString(2);

			String mensaje = StringUtils.substring(resultado, 48, 123);

			RecuperarBonoRta rta = new RecuperarBonoRta();

			rta.setCodigoRespuesta(StringUtils.substring(resultado, 46, 48));

			if (StringUtils.isNotBlank(mensaje)) {
				rta.setDescripcionRespuesta(mensaje.trim());
			}

			Stream<String> bonos = Stream.of(StringUtils.substring(resultado, 160, 1459).trim().split(";"));

			List<Bono> bonosList = (List<Bono>) bonos.filter(s -> (s.length() > 0)).map(s -> {
				String[] data = s.split(",");
				Bono b = new Bono();
				b.setNumero(data[0]);
				b.setValor(Long.valueOf(data[1].substring(0, data[1].length() - 2)));
				return b;
			}).collect(Collectors.toList());

			rta.setBonos(bonosList);

			exchange.getIn().setBody(rta);
		}
	}

	public static Object getKeyFromValue(Map hm, Object value) {
		for (Object o : hm.keySet()) {
			if (hm.get(o).equals(value)) {
				return o;
			}
		}
		return null;
	}
}
