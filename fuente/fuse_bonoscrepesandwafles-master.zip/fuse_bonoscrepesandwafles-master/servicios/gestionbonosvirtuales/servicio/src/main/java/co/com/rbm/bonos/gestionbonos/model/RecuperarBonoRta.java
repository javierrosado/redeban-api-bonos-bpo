package co.com.rbm.bonos.gestionbonos.model;

import java.util.List;

public class RecuperarBonoRta {
	private String codigoRespuesta;
	private String descripcionRespuesta;
	List<Bono> bonos;

	public List<Bono> getBonos() {
		return this.bonos;
	}

	public void setBonos(List<Bono> bonos) {
		this.bonos = bonos;
	}

	public String getCodigoRespuesta() {
		return this.codigoRespuesta;
	}

	public void setCodigoRespuesta(String codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}

	public String getDescripcionRespuesta() {
		return this.descripcionRespuesta;
	}

	public void setDescripcionRespuesta(String descripcionRespuesta) {
		this.descripcionRespuesta = descripcionRespuesta;
	}
}
