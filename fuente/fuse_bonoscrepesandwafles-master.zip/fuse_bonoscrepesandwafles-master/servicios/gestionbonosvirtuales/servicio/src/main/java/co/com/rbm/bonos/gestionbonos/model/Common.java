package co.com.rbm.bonos.gestionbonos.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;

public class Common extends CommonBono {
	@NotNull(message = "El campo subtipo no puede ser null")
	@NotEmpty(message = "El campo subtipo no puede estar vacio")
	@Size(min = 3, max = 3, message = "La longitud del campo subtipo debe ser 3")
	private String subtipo;

	public String getSubtipo() {
		return this.subtipo;
	}

	public void setSubtipo(String subtipo) {
		this.subtipo = subtipo;
	}
}
