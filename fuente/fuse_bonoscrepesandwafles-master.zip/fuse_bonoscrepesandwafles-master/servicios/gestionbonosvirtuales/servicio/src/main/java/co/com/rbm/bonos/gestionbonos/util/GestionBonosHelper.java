package co.com.rbm.bonos.gestionbonos.util;

import co.com.rbm.bonos.gestionbonos.model.ResponseError;
import java.net.ConnectException;
import javax.validation.ConstraintViolation;
import javax.ws.rs.core.Response;
import org.apache.camel.Exchange;
import org.apache.camel.component.bean.validator.BeanValidationException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.CannotGetJdbcConnectionException;

public class GestionBonosHelper {
	private static final Logger LOG = LoggerFactory.getLogger(GestionBonosHelper.class);
	public static final String TIME_OUT_MESSAGE = "Connection timed out";

	public void buildResponseError(Exchange e) {
		String codigoHttp = (String) e.getProperty("codigohttp", String.class);
		String codigoRespuesta = (String) e.getProperty("codigo", String.class);
		String descriptionRespuesta = (String) e.getProperty("descripcion", String.class);
		Exception exception = (Exception) e.getProperty("CamelExceptionCaught", Exception.class);

		try {
			if (exception instanceof BeanValidationException) {

				try {
					BeanValidationException beanException = (BeanValidationException) exception;

					descriptionRespuesta = descriptionRespuesta + ": ";

					for (ConstraintViolation<Object> constraintViolation : (Iterable<ConstraintViolation<Object>>) beanException
							.getConstraintViolations()) {
						descriptionRespuesta = descriptionRespuesta + constraintViolation.getPropertyPath() + " => "
								+ constraintViolation.getMessage() + ", ";
					}
				} catch (Exception except) {
					descriptionRespuesta = "No description error";
				}
			} else if (exception instanceof CannotGetJdbcConnectionException) {
				CannotGetJdbcConnectionException connectionException = (CannotGetJdbcConnectionException) exception;
				if (ExceptionUtils.indexOfThrowable((Throwable) connectionException, ConnectException.class) != -1) {
					codigoRespuesta = e.getContext().resolvePropertyPlaceholders("{{codigo.E10}}");
					descriptionRespuesta = e.getContext().resolvePropertyPlaceholders("{{descripcion.E10}}");
				}

			} else if (exception instanceof java.sql.SQLException && StringUtils.isNotBlank(exception.getMessage())
					&& StringUtils.containsIgnoreCase(exception.getMessage(), "Connection timed out")) {
				codigoRespuesta = e.getContext().resolvePropertyPlaceholders("{{codigo.E10}}");
				descriptionRespuesta = e.getContext().resolvePropertyPlaceholders("{{descripcion.E10}}");
			}

		} catch (Exception exc) {
			codigoHttp = "500";
			codigoRespuesta = "E09";
			descriptionRespuesta = "Error interno del servicio";
			LOG.error(exc.getMessage());
		}
		ResponseError error = new ResponseError();
		error.setCodigoError(codigoRespuesta);
		error.setDescripcionError(descriptionRespuesta);
		e.getOut().setHeader("CamelHttpResponseCode", codigoHttp);
		e.getOut().setBody(Response.status(Integer.parseInt(codigoHttp)).entity(error).build());
	}
}
