package co.com.rbm.bonos.gestionbonos.route;

import co.com.rbm.bonos.gestionbonos.dao.AS400DAO;
import co.com.rbm.bonos.gestionbonos.model.ActivaCargaBono;
import co.com.rbm.bonos.gestionbonos.model.CrearBono;
import co.com.rbm.bonos.gestionbonos.model.RecuperarBono;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.apache.camel.Exchange;
import org.apache.camel.Expression;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.bean.validator.BeanValidationException;
import org.apache.camel.model.OnExceptionDefinition;
import org.apache.camel.model.RouteDefinition;
import org.apache.commons.dbcp.SQLNestedException;
import org.apache.commons.lang.StringUtils;
import org.springframework.jdbc.CannotGetJdbcConnectionException;

public class GestionBonosRouteBuilder extends RouteBuilder {
	public void configure() throws Exception {
		((OnExceptionDefinition) ((OnExceptionDefinition) ((OnExceptionDefinition) ((OnExceptionDefinition) ((OnExceptionDefinition) onException(
				BeanValidationException.class).handled(true).log(LoggingLevel.ERROR,
						"ERROR: ${camelId} || ${routeId} || errores${exception.message.split('errors')[1]}"))
								.log(LoggingLevel.DEBUG, "ERROR: ${camelId} || ${routeId} || ${exception.stacktrace}"))
										.setProperty("codigohttp",
												(Expression) simple("{{codigo.respuesta.error.estructura}}")))
														.setProperty("codigo", (Expression) simple("{{codigo.E01}}")))
																.setProperty("descripcion",
																		(Expression) simple("{{descripcion.E01}}")))
																				.to("direct:error");

		((OnExceptionDefinition) ((OnExceptionDefinition) ((OnExceptionDefinition) ((OnExceptionDefinition) ((OnExceptionDefinition) onException(
				CannotGetJdbcConnectionException.class).handled(true).log(LoggingLevel.ERROR,
						"ERROR: ${camelId} || ${routeId} || ${exception.message}")).log(LoggingLevel.DEBUG,
								"ERROR: ${camelId} || ${routeId} || ${exception.stacktrace}")).setProperty("codigohttp",
										(Expression) simple("{{codigo.respuesta.error.general}}")))
												.setProperty("codigo", (Expression) simple("{{codigo.E08}}")))
														.setProperty("descripcion",
																(Expression) simple("{{descripcion.E08}}")))
																		.to("direct:error");

		((OnExceptionDefinition) ((OnExceptionDefinition) ((OnExceptionDefinition) ((OnExceptionDefinition) ((OnExceptionDefinition) onException(
				SQLNestedException.class).handled(true).log(LoggingLevel.ERROR,
						"ERROR: ${camelId} || ${routeId} || ${exception.message}")).log(LoggingLevel.DEBUG,
								"ERROR: ${camelId} || ${routeId} || ${exception.stacktrace}")).setProperty("codigohttp",
										(Expression) simple("{{codigo.respuesta.error.general}}")))
												.setProperty("codigo", (Expression) simple("{{codigo.E08}}")))
														.setProperty("descripcion",
																(Expression) simple("{{descripcion.E08}}")))
																		.to("direct:error");

		((OnExceptionDefinition) ((OnExceptionDefinition) ((OnExceptionDefinition) ((OnExceptionDefinition) ((OnExceptionDefinition) onException(
				Exception.class).handled(true).log(LoggingLevel.ERROR,
						"ERROR: ${camelId} || ${routeId} || ${exception.message}")).log(LoggingLevel.DEBUG,
								"ERROR: ${camelId} || ${routeId} || ${exception.stacktrace}")).setProperty("codigohttp",
										(Expression) simple("{{codigo.respuesta.error.general}}")))
												.setProperty("codigo", (Expression) simple("{{codigo.E09}}")))
														.setProperty("descripcion",
																(Expression) simple("{{descripcion.E09}}")))
																		.to("direct:error");

		((RouteDefinition) ((RouteDefinition) ((RouteDefinition) ((RouteDefinition) ((RouteDefinition) from(
				"cxfrs:bean:restApiEnpoint?bindingStyle=SimpleConsumer").routeId("RT-MAIN-GESTION-BONOS-VIRTUALES")
						.removeHeaders("org.apache.cxf.headers*")).to("bean-validator://requestValidador"))
								.setProperty("codApp", (Expression) simple("{{bonos.codigo.aplicacion}}")))
										.setProperty("codSwitch", (Expression) simple("{{bonos.codigo.switch}}")))
												.setProperty("sp",
														(Expression) simple("{{bonos.as400.store.procedure}}")))
																.toD("direct:${header.operationName}");

		((RouteDefinition) ((RouteDefinition) from("direct:crearBono").routeId("RT-CREAR-BONO")
				.setHeader("codigoNovedad", (Expression) simple("{{bonos.codigo.novedad.crear}}"))).process(e -> {
					StringBuilder trama = new StringBuilder();

					CrearBono crearBono = (CrearBono) e.getIn().getBody(CrearBono.class);
					buildCommonTrama(e, trama);
					trama.append(StringUtils.rightPad(crearBono.getBin(), 6));
					trama.append(StringUtils.rightPad(crearBono.getSubtipo(), 3));
					trama.append(StringUtils.leftPad(crearBono.getNit(), 15, "0"));
					trama.append(StringUtils.rightPad("", 2));
					trama.append(StringUtils.rightPad("", 75));
					trama.append(StringUtils.rightPad("", 19));
					trama.append(
							StringUtils.rightPad((String) AS400DAO.documentos.get(crearBono.getTipoDocumento()), 2));
					trama.append(StringUtils.leftPad(crearBono.getNumeroDocumento(), 15, "0"));
					trama.append(StringUtils.rightPad(crearBono.getNombre(), 22));
					trama.append(StringUtils.rightPad("", 19));
					trama.append(StringUtils.rightPad("", 1824));
					e.getIn().setBody(trama.toString());
				})).to("bean:as400dao?method=crearBono");

		((RouteDefinition) ((RouteDefinition) ((RouteDefinition) ((RouteDefinition) ((RouteDefinition) from(
				"direct:activarBono").routeId("RT-ACTIVAR-BONO").setHeader("codigoNovedad",
						(Expression) simple("{{bonos.codigo.novedad.activar}}"))).setHeader("codTransaccion",
								(Expression) simple("{{bonos.codigo.transaccion.activacion}}"))).setHeader(
										"dispositivo", (Expression) simple("{{bonos.dispositivo.activacion}}")))
												.setHeader("tipoTransaccion",
														(Expression) simple("{{bonos.tipo.transaccion.activacion}}")))
																.process(e -> {
																	StringBuilder trama = new StringBuilder();

																	ActivaCargaBono activaCargaBono = (ActivaCargaBono) e
																			.getIn().getBody(ActivaCargaBono.class);

																	buildCommonTrama(e, trama);
																	trama.append(StringUtils
																			.rightPad(activaCargaBono.getBin(), 6));
																	trama.append(StringUtils
																			.rightPad(activaCargaBono.getSubtipo(), 3));
																	trama.append(StringUtils.leftPad(
																			activaCargaBono.getNit(), 15, "0"));
																	trama.append(StringUtils.rightPad("", 2));
																	trama.append(StringUtils.rightPad("", 75));
																	trama.append(StringUtils.rightPad("", 19));
																	trama.append(StringUtils.rightPad(
																			activaCargaBono.getNumeroBono(), 19));
																	trama.append(StringUtils.leftPad(
																			activaCargaBono.getValorCarga() + "00", 12,
																			"0"));
																	trama.append((String) e.getIn()
																			.getHeader("codTransaccion", String.class));
																	trama.append((String) e.getIn()
																			.getHeader("dispositivo", String.class));
																	trama.append(StringUtils.rightPad(
																			activaCargaBono.getNumeroAuditoria(), 6));
																	trama.append(StringUtils.rightPad(
																			activaCargaBono.getConsecutivo(), 12));
																	trama.append((String) e.getIn().getHeader(
																			"tipoTransaccion", String.class));
																	trama.append(StringUtils.rightPad("", 6));
																	trama.append(StringUtils.rightPad("", 2));
																	trama.append(StringUtils.rightPad("", 16));
																	trama.append(StringUtils.rightPad("", 25));
																	trama.append(StringUtils.rightPad("", 19));
																	trama.append(StringUtils.rightPad("", 1));
																	trama.append(StringUtils.rightPad("", 1752));
																	e.getIn().setBody(trama.toString(), String.class);
																})).to("bean:as400dao?method=activarBono");

		((RouteDefinition) ((RouteDefinition) from("direct:recuperarBono").routeId("RT-RECUPERAR-BONO")
				.setHeader("codigoNovedad", (Expression) simple("{{bonos.codigo.novedad.consultar}}")))

						.process(e -> {
							StringBuilder trama = new StringBuilder();

							RecuperarBono recuperarBono = (RecuperarBono) e.getIn().getBody(RecuperarBono.class);
							buildCommonTrama(e, trama);
							trama.append(StringUtils.rightPad(recuperarBono.getBin(), 6));
							trama.append(StringUtils.rightPad(recuperarBono.getSubtipo(), 3));
							trama.append(StringUtils.leftPad(recuperarBono.getNit(), 15, "0"));
							trama.append(StringUtils.rightPad("", 2));
							trama.append(StringUtils.rightPad("", 75));
							trama.append(StringUtils.rightPad("", 19));
							trama.append(StringUtils
									.rightPad((String) AS400DAO.documentos.get(recuperarBono.getTipoDocumento()), 2));
							trama.append(StringUtils.leftPad(recuperarBono.getNumeroDocumento(), 15, "0"));
							trama.append(StringUtils.rightPad("", 1300));
							trama.append(StringUtils.rightPad("", 565));
							e.getIn().setBody(trama.toString(), String.class);
						})).to("bean:as400dao?method=recuperarBono");

		from("direct:error").to("bean:helper?method=buildResponseError");
	}

	private String formatterDate(LocalDateTime time, String format) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
		return time.format(formatter);
	}

	public void buildCommonTrama(Exchange exchange, StringBuilder trama) {
		trama.append((String) exchange.getProperty("codApp", String.class));
		trama.append((String) exchange.getProperty("codSwitch", String.class));
		trama.append((String) exchange.getIn().getHeader("codigoNovedad", String.class));
		trama.append(formatterDate(LocalDateTime.now(), "yyyyMMdd"));
		trama.append(formatterDate(LocalDateTime.now(), "HHmmss"));
	}
}
