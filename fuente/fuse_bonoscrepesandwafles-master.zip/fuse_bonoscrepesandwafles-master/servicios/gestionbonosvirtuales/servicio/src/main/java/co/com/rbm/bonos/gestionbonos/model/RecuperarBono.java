package co.com.rbm.bonos.gestionbonos.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;

public class RecuperarBono extends Common {
	@NotNull(message = "El campo tipoDocumento no puede ser null")
	@NotEmpty(message = "El campo tipoDocumento no puede estar vacio")
	@Size(min = 2, max = 2, message = "La longitud del campo tipoDocumento debe ser 2")
	@Pattern(regexp = "CC|NI|TR|CE|TI|PS|NU|RC", message = "Los valores para el campo tipoDocumento son CC,NI,TR,CE,TI,PS,NU,RC")
	private String tipoDocumento;
	@NotNull(message = "El campo numeroDocumento no puede ser null")
	@NotEmpty(message = "El campo numeroDocumento no puede estar vacio")
	@Size(min = 6, max = 15, message = "La longitud del campo numeroDocumento debe estar entre 6 y 15")
	@Pattern(regexp = "[0-9]+", message = "El campo numeroDocumento es numerico")
	private String numeroDocumento;

	public String getTipoDocumento() {
		return this.tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return this.numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
}
