package co.com.rbm.bonos.gestionbonos.model;

public class Bono {
	private String numero;

	public String getNumero() {
		return this.numero;
	}

	private Long valor;

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public Long getValor() {
		return this.valor;
	}

	public void setValor(Long valor) {
		this.valor = valor;
	}
}
