package co.com.rbm.bonos.gestionbonos.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;

public class CommonBono {
	@NotNull(message = "El campo bin no puede ser null")
	@NotEmpty(message = "El campo bin no puede estar vacio")
	@Size(min = 6, max = 6, message = "La longitud del campo bin debe ser 6")
	@Pattern(regexp = "[0-9]+", message = "El campo bin es numerico")
	private String bin;
	@NotNull(message = "El campo nit no puede ser null")
	@NotEmpty(message = "El campo nit no puede estar vacio")
	@Size(min = 9, max = 15, message = "La longitud del campo nit debe estar entre 9 y 15")
	@Pattern(regexp = "[0-9]+", message = "El campo nit es numerico")
	private String nit;

	public String getBin() {
		return this.bin;
	}

	public void setBin(String bin) {
		this.bin = bin;
	}

	public String getNit() {
		return this.nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}
}
