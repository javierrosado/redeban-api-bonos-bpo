package co.com.rbm.bonos.gestionbonos.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;

public class ActivaCargaBono extends Common {
	@NotNull(message = "El campo numeroBono no puede ser null")
	@NotEmpty(message = "El campo numeroBono no puede estar vacio")
	@Size(min = 13, max = 19, message = "La longitud del campo numeroBono debe estar entre 13 y 19")
	private String numeroBono;
	@NotNull(message = "El campo valorCarga no puede ser null")
	@NotEmpty(message = "El campo valorCarga no puede estar vacio")
	@Size(min = 5, max = 10, message = "La longitud del campo valorCarga debe ser 10")
	@Pattern(regexp = "[0-9]+", message = "El campo valorCarga es numerico")
	private String valorCarga;
	@NotNull(message = "El campo numeroAuditoria no puede ser null")
	@NotEmpty(message = "El campo numeroAuditoria no puede estar vacio")
	@Size(min = 6, max = 6, message = "La longitud del campo numeroAuditoria debe ser 6")
	@Pattern(regexp = "[0-9]+", message = "El campo numeroAuditoria es numerico")
	private String numeroAuditoria;
	@NotNull(message = "El campo consecutivo no puede ser null")
	@NotEmpty(message = "El campo consecutivo no puede estar vacio")
	@Size(min = 2, max = 12, message = "La longitud del campo consecutivo debe ser 12")
	@Pattern(regexp = "[0-9]+", message = "El campo consecutivo es numerico")
	private String consecutivo;

	public String getNumeroBono() {
		return this.numeroBono;
	}

	public void setNumeroBono(String numeroBono) {
		this.numeroBono = numeroBono;
	}

	public String getValorCarga() {
		return this.valorCarga;
	}

	public void setValorCarga(String valorCarga) {
		this.valorCarga = valorCarga;
	}

	public String getNumeroAuditoria() {
		return this.numeroAuditoria;
	}

	public void setNumeroAuditoria(String numeroAuditoria) {
		this.numeroAuditoria = numeroAuditoria;
	}

	public String getConsecutivo() {
		return this.consecutivo;
	}

	public void setConsecutivo(String consecutivo) {
		this.consecutivo = consecutivo;
	}
}
