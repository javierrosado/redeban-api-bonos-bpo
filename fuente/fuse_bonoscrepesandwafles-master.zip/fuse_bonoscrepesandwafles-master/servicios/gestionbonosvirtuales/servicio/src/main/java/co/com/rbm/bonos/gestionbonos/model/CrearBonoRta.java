package co.com.rbm.bonos.gestionbonos.model;

public class CrearBonoRta {
	private String numeroBono;
	private String codigoRespuesta;
	private String descripcionRespuesta;

	public String getNumeroBono() {
		return this.numeroBono;
	}

	public void setNumeroBono(String numeroBono) {
		this.numeroBono = numeroBono;
	}

	public String getCodigoRespuesta() {
		return this.codigoRespuesta;
	}

	public void setCodigoRespuesta(String codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}

	public String getDescripcionRespuesta() {
		return this.descripcionRespuesta;
	}

	public void setDescripcionRespuesta(String descripcionRespuesta) {
		this.descripcionRespuesta = descripcionRespuesta;
	}
}
